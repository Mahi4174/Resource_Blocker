package com.company.app.dto;

public class AddReservationDTO {
    private Long resourceId;
    private String email;
    private String description;

    public AddReservationDTO() {
    }

    public AddReservationDTO(Long resourceId, String email, String description) {
        this.resourceId = resourceId;
        this.email = email;
        this.description = description;
    }

    public Long getResourceId() {
        return resourceId;
    }

    public void setResourceId(Long resourceId) {
        this.resourceId = resourceId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
