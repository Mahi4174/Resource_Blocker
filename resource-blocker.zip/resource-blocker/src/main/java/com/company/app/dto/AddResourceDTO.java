package com.company.app.dto;

import com.company.app.enums.ResourceTypeEnum;

public class AddResourceDTO {
	private String name;
	private String description;
	private ResourceTypeEnum type;
	private String location;
	
	
	public AddResourceDTO() {
		super();
	}
	public AddResourceDTO(String name, String description, ResourceTypeEnum type,  String location) {
		super();
		this.name = name;
		this.description = description;
		this.type = type;
		this.location = location;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public ResourceTypeEnum getType() {
		return type;
	}
	public void setType(ResourceTypeEnum type) {
		this.type = type;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
