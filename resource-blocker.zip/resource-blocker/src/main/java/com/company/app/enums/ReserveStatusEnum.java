package com.company.app.enums;

public enum ReserveStatusEnum {
    PENDING,
    APPROVED,
    REJECTED
}
