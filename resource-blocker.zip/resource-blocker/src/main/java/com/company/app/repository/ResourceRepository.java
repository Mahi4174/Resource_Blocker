package com.company.app.repository;

import com.company.app.enums.ResourceTypeEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.company.app.model.Resource;

import java.util.List;

@Repository
public interface ResourceRepository extends JpaRepository<Resource,Long> {
    List<Resource> findByLocationLikeIgnoreCaseOrType(String location, ResourceTypeEnum type);

}
