package com.company.app.dto;

public class FetchDetailsDTO {
    private String email;

    public FetchDetailsDTO() {
    }

    public FetchDetailsDTO(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
