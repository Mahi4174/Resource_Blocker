package com.company.app.model;

import com.company.app.enums.ReserveStatusEnum;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne
    private User user;
    @OneToOne
    private Resource resource;
    private String remark;
    private String description;
    private ReserveStatusEnum status;
    private LocalDateTime createdAt;

    public Reservation() {
    }

    public Reservation(Long id, User user, Resource resource, String remark, String description, ReserveStatusEnum status, LocalDateTime createdAt) {
        this.id = id;
        this.user = user;
        this.resource = resource;
        this.remark = remark;
        this.description = description;
        this.status = status;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Resource getResource() {
        return resource;
    }

    public void setResource(Resource resource) {
        this.resource = resource;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ReserveStatusEnum getStatus() {
        return status;
    }

    public void setStatus(ReserveStatusEnum status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
