package com.company.app.dto;

import com.company.app.enums.ResourceTypeEnum;

public class SearchResourceDTO {
    private String location;
    private ResourceTypeEnum resourceType;

    public SearchResourceDTO() {
    }

    public SearchResourceDTO(String location, ResourceTypeEnum resourceType) {
        this.location = location;
        this.resourceType = resourceType;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public ResourceTypeEnum getResourceType() {
        return resourceType;
    }

    public void setResourceType(ResourceTypeEnum resourceType) {
        this.resourceType = resourceType;
    }
}
