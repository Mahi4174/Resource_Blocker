package com.company.app.dto;

import java.time.LocalDate;

public class UserRegisterDTO {
    private String email;
    private Long ssn;
    private String dateOfJoining;
    private String password;
    private String address;

    public UserRegisterDTO() {
    }

    public UserRegisterDTO(String email, Long ssn, String dateOfJoining, String password, String address) {
        this.email = email;
        this.ssn = ssn;
        this.dateOfJoining = dateOfJoining;
        this.password = password;
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getSsn() {
        return ssn;
    }

    public void setSsn(Long ssn) {
        this.ssn = ssn;
    }

    public String getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(String dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
