package com.company.app.controller;

import com.company.app.dto.AddReservationDTO;
import com.company.app.enums.ReserveStatusEnum;
import com.company.app.enums.ResourceStatusEnum;
import com.company.app.model.Reservation;
import com.company.app.model.Resource;
import com.company.app.model.User;
import com.company.app.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.company.app.dto.AddResourceDTO;
import com.company.app.enums.ResourceTypeEnum;
import com.company.app.repository.ResourceRepository;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	private ResourceRepository resourceRepository;
	@Autowired
	private ReservationRepository reservationRepository;

	@GetMapping({"/add-resource"})
    public String createResourceView(Model model) {
		List<Resource> resourceList = resourceRepository.findAll();
		model.addAttribute("resourceTypes",getResourceTypes());
		model.addAttribute("resourceList",resourceList);
        return "add-resource";
    }

	@GetMapping("/")
	public String home(Model model) {
		model.addAttribute("message","Welcome to admin portal");
		model.addAttribute("isAdmin",true);
		return "home";
	}
	@PostMapping("/add-resource")
	public RedirectView createResource(@ModelAttribute("resource") AddResourceDTO r, RedirectAttributes redirectAttributes) {
		final RedirectView redirectView = new RedirectView("/admin/add-resource", true);
		redirectAttributes.addFlashAttribute("alertMessage", "Successfully resource added");
		redirectAttributes.addFlashAttribute("alertPresent", true);
		Resource resource = new Resource(null, r.getName(), r.getDescription(),r.getType(), LocalDateTime.now(), r.getLocation());
		resource.setStatus(ResourceStatusEnum.VACANT);
		resourceRepository.save(resource);
		return redirectView;
	}

	@GetMapping("/delete-resource/{resourceId}")
	public RedirectView createResource(Model model, @PathVariable("resourceId") Long resourceId, RedirectAttributes redirectAttributes){
		final RedirectView redirectView = new RedirectView("/admin/add-resource", true);
		resourceRepository.deleteById(resourceId);
		redirectAttributes.addFlashAttribute("alertMessage", "Successfully resource deleted");
		redirectAttributes.addFlashAttribute("alertPresent", true);
		return  redirectView;
	}
	//activeResource
	@GetMapping({"/update-resource/{resourceId}"})
	public String updateResourceView(Model model, @PathVariable("resourceId") Long resourceId) {
		Resource activeResource = resourceRepository.findById(resourceId).orElseThrow(() -> new RuntimeException("Resource not found"));
		model.addAttribute("activeResource",activeResource);
		model.addAttribute("resourceTypes",getResourceTypes());
		return "update-resource";
	}
	@PostMapping("/update-resource")
	public RedirectView updateResource(@ModelAttribute("resource") Resource r, RedirectAttributes redirectAttributes) {
		final RedirectView redirectView = new RedirectView("/admin/add-resource", true);
		redirectAttributes.addFlashAttribute("alertMessage", "Successfully resource updated");
		redirectAttributes.addFlashAttribute("alertPresent", true);
		Resource resource = resourceRepository.findById(r.getId()).orElseThrow(() -> new RuntimeException("Resource not found"));
		resource.setDescription(r.getDescription());
		resource.setName(r.getName());
		resource.setType(r.getType());
		resource.setLocation(r.getLocation());
		resourceRepository.save(resource);
		return redirectView;
	}

	@GetMapping("/resource-requests")
	public String resourceReservationListView(Model model) {
		List<Reservation> reservationList = reservationRepository.findAll();
		model.addAttribute("reservationList",reservationList);
		return "requests-list";
	}

	@GetMapping("/resource-requests-reject/{resId}")
	public RedirectView resourceReservationReject(@PathVariable("resId") Long resId, Model model, RedirectAttributes redirectAttributes) {
		final RedirectView redirectView = new RedirectView("/admin/resource-requests", true);
		Optional<Reservation> _resource = reservationRepository.findById(resId);
		if(!_resource.isPresent()){
			redirectAttributes.addFlashAttribute("errorMessage", "Reservation not found");
			redirectAttributes.addFlashAttribute("errorPresent", true);
			return redirectView;
		}
		Reservation reservation = _resource.get();
		reservation.setStatus(ReserveStatusEnum.REJECTED);
		Resource resource = reservation.getResource();
		resource.setStatus(ResourceStatusEnum.VACANT);
		resourceRepository.save(resource);
		reservationRepository.save(reservation);
		redirectAttributes.addFlashAttribute("alertMessage", "Successfully reservation rejected");
		redirectAttributes.addFlashAttribute("alertPresent", true);
		return redirectView;
	}
	@GetMapping("/resource-requests-approve/{resId}")
	@Transactional
	public RedirectView resourceReservationApprove(@PathVariable("resId") Long resId, Model model, RedirectAttributes redirectAttributes) {
		final RedirectView redirectView = new RedirectView("/admin/resource-requests", true);
		Optional<Reservation> _resource = reservationRepository.findById(resId);
		if(!_resource.isPresent()){
			redirectAttributes.addFlashAttribute("errorMessage", "Reservation not found");
			redirectAttributes.addFlashAttribute("errorPresent", true);
			return redirectView;
		}
		Reservation reservation = _resource.get();
		reservation.setStatus(ReserveStatusEnum.APPROVED);
		Resource resource = reservation.getResource();
		resource.setStatus(ResourceStatusEnum.ALLOCATED);
		resourceRepository.save(resource);
		reservationRepository.save(reservation);
		redirectAttributes.addFlashAttribute("alertMessage", "Successfully reservation approved");
		redirectAttributes.addFlashAttribute("alertPresent", true);
		return redirectView;
	}
	public ResourceTypeEnum[] getResourceTypes() {
		return ResourceTypeEnum.values();
	}
}
