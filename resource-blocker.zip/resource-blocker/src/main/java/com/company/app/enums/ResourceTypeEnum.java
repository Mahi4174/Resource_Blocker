package com.company.app.enums;

public enum ResourceTypeEnum {
	CONFERENCE_ROOM,
	PROJECT_CUBICLE,
	FLEX_CUBICLE,
	LAPTOP,
	PROJECTOR
}
