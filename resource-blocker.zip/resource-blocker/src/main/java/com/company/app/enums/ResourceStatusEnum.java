package com.company.app.enums;

public enum ResourceStatusEnum {
    VACANT,
    ALLOCATED,
}
