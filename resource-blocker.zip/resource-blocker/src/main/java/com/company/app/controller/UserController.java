package com.company.app.controller;

import com.company.app.dto.AddReservationDTO;
import com.company.app.dto.FetchDetailsDTO;
import com.company.app.dto.SearchResourceDTO;
import com.company.app.dto.UserRegisterDTO;
import com.company.app.enums.ReserveStatusEnum;
import com.company.app.enums.ResourceStatusEnum;
import com.company.app.enums.ResourceTypeEnum;
import com.company.app.model.Reservation;
import com.company.app.model.Resource;
import com.company.app.model.User;
import com.company.app.repository.ReservationRepository;
import com.company.app.repository.ResourceRepository;
import com.company.app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ResourceRepository resourceRepository;

    @Autowired
    private ReservationRepository reservationRepository;

    @GetMapping({"/register"})
    public String createUserView(Model model) {
        return "register-user";
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("message","Welcome to employee portal");
        model.addAttribute("isAdmin",false);
        return "home";
    }

    @PostMapping("/register")
    public RedirectView createUser(@ModelAttribute("UserRegisterDTO") UserRegisterDTO r, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/register", true);
        if(userRepository.existsByEmailIgnoreCase(r.getEmail()) || userRepository.existsBySsn(r.getSsn())){
            redirectAttributes.addFlashAttribute("errorMessage", "User already exists");
            redirectAttributes.addFlashAttribute("errorPresent", true);
            return redirectView;
        }
        redirectAttributes.addFlashAttribute("alertMessage", "Successfully user added");
        redirectAttributes.addFlashAttribute("alertPresent", true);
        User user = new User(null, r.getEmail(),r.getSsn(),r.getDateOfJoining(), r.getPassword(), r.getAddress(), LocalDateTime.now());
        userRepository.save(user);
        return redirectView;
    }

    @GetMapping("/fetch-details")
    public String updateDetailsView(Model model) {
        return "fetch-profile";
    }

    @PostMapping("/fetch-details")
    public RedirectView updateDetailsPost(@ModelAttribute("FetchDetailsDTO") FetchDetailsDTO r, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/fetch-details", true);
        Optional<User> user = userRepository.findByEmailIgnoreCase(r.getEmail());
        if(!user.isPresent()){
            redirectAttributes.addFlashAttribute("errorMessage", "User not found");
            redirectAttributes.addFlashAttribute("errorPresent", true);
            return redirectView;
        }
        redirectAttributes.addFlashAttribute("showDetails", true);
        redirectAttributes.addFlashAttribute("userDetails", user.get());
        return redirectView;
    }
    @PostMapping("/fetch-details/update")
    public RedirectView updateDetails(@ModelAttribute("UserRegisterDTO") UserRegisterDTO r, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/fetch-details", true);
        Optional<User> _user = userRepository.findByEmailIgnoreCase(r.getEmail());
        if(!_user.isPresent()){
            redirectAttributes.addFlashAttribute("errorMessage", "User not found");
            redirectAttributes.addFlashAttribute("errorPresent", true);
            return redirectView;
        }
        User user = _user.get();
        user.setAddress(r.getAddress());
        user.setDateOfJoining(r.getDateOfJoining());
        user.setSsn(r.getSsn());
        user.setPassword(r.getPassword());
        userRepository.save(user);
        redirectAttributes.addFlashAttribute("alertMessage", "Successfully user updated");
        redirectAttributes.addFlashAttribute("alertPresent", true);
        redirectAttributes.addFlashAttribute("showDetails", true);
        redirectAttributes.addFlashAttribute("userDetails",user );
        return redirectView;
    }

    @GetMapping("/search-resource")
    public String searchResourceView(Model model) {
        List<Resource> resourceList = resourceRepository.findAll();
        model.addAttribute("resourceTypes", ResourceTypeEnum.values());
        model.addAttribute("resourceList",resourceList);
        return "search-resource";
    }

    @PostMapping("/search-resource")
    public RedirectView searchResourcePost(@ModelAttribute("SearchResourceDTO") SearchResourceDTO r, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/search-resource", true);
        List<Resource> resourceList = resourceRepository.findByLocationLikeIgnoreCaseOrType(r.getLocation(), r.getResourceType());
        redirectAttributes.addFlashAttribute("searchResourceList", resourceList);
        redirectAttributes.addFlashAttribute("searchPerform", true);
        return redirectView;
    }

    @GetMapping("/reserve-resource/{resourceId}")
    public String reserveResourceView(Model model, @PathVariable("resourceId") Long resourceId) {
        Resource resource = resourceRepository.findById(resourceId).orElseThrow(() -> new RuntimeException("Resource not found"));
        model.addAttribute("resourceTypes", ResourceTypeEnum.values());
        model.addAttribute("activeResource",resource);
        return "reserve-resource";
    }
    @PostMapping("/reserve-resource")
    public RedirectView reserveResourcePost(@ModelAttribute("AddReservationDTO") AddReservationDTO r, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/search-resource", true);
        Resource resource = resourceRepository.findById(r.getResourceId()).orElseThrow(() -> new RuntimeException("Resource not found"));
        Optional<User> _user = userRepository.findByEmailIgnoreCase(r.getEmail());
        if(!_user.isPresent()){
            redirectAttributes.addFlashAttribute("errorMessage", "User not found");
            redirectAttributes.addFlashAttribute("errorPresent", true);
            return redirectView;
        }
        User user = _user.get();
        Reservation reservation = new Reservation(null, user,resource,"", r.getDescription(), ReserveStatusEnum.PENDING,LocalDateTime.now());
        reservationRepository.save(reservation);
        redirectAttributes.addFlashAttribute("alertMessage", "Successfully resource request raised");
        redirectAttributes.addFlashAttribute("alertPresent", true);
        return redirectView;
    }

    @GetMapping("/my-reservations")
    public String fetchUserView(Model model) {
        return "my-reservations";
    }

    @GetMapping("/reservations-cancel/{resId}")
    public RedirectView fetchMyReservationCancel(@PathVariable("resId") Long resId, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/my-reservations", true);
        Optional<Reservation> _resource = reservationRepository.findById(resId);
        if(!_resource.isPresent()){
            redirectAttributes.addFlashAttribute("errorMessage", "Reservation not found");
            redirectAttributes.addFlashAttribute("errorPresent", true);
            return redirectView;
        }
        Reservation reservation = _resource.get();
        Resource resource = reservation.getResource();
        resource.setStatus(ResourceStatusEnum.VACANT);
        resourceRepository.save(resource);
        reservationRepository.deleteById(resId);
        redirectAttributes.addFlashAttribute("alertMessage", "Successfully reservation cancel");
        redirectAttributes.addFlashAttribute("alertPresent", true);
        return redirectView;
    }

    @PostMapping("/my-reservations")
    public RedirectView fetchMyReservation(@ModelAttribute("FetchDetailsDTO") FetchDetailsDTO r, RedirectAttributes redirectAttributes) {
        final RedirectView redirectView = new RedirectView("/user/my-reservations", true);
        Optional<User> user = userRepository.findByEmailIgnoreCase(r.getEmail());
        if(!user.isPresent()){
            redirectAttributes.addFlashAttribute("errorMessage", "User not found");
            redirectAttributes.addFlashAttribute("errorPresent", true);
            return redirectView;
        }
        List<Reservation> reservationList = reservationRepository.findByUser_EmailIgnoreCase(r.getEmail());
        redirectAttributes.addFlashAttribute("showDetails", true);
        redirectAttributes.addFlashAttribute("reservationList", reservationList);
        return redirectView;
    }
}
//aarati@gmail.com